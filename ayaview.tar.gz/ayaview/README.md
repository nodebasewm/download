# Ayaview v0.0.1 

## Description

Ayaview is a lightweight console-base viewer for the WM Aya Chain validator.
It display node status, session block and system events.

## How to use

console-based lightweight observer for worldmobile aya validators

Usage:
  ayaview [flags]

Flags:
  -c, --config string        Defines the path to the config file
  -h, --help                 help for ayaview
  -l, --level string         loglevel (panic,fatal,error,warn,info,debug,trace,disabled)
  -f, --log-file string      name of log file
  -r, --rpc-address string   Defines the validator RPC port to connect to
  -n, --validator string     Validator node ID
  -v, --version              Displays version information

You could either use the config file or command-line parameters, when used
together the command-lines parameters the config.


## Configuration

### validator

validator=""
You should fill the validate node ID in "validator", this is the ID, which currently
corresponds to the wallet addressed used to register the validator session keys.
Should be something like "0x..."

## rpc_address

rpc_address = "ws://localhost:9944"
RPC address is a rpc port to talk too, this could either be a local or remote address.
Use **ws://localhost:9944**  if you are running ayaview on localhost, this connects to your local validator on the default  port **9944**. If you changed the default RPC port 9944 to something else then reflect it in this value.

## Logging

level: disabled
log_file: ayaview.log

These control logging options for tracing. Level can be one  panic,fatal,error,warn,info,debug,trace,disabled
Log_file is the file to trace too. By default it writes to file called 'ayaview.log' in current working directory, which corresponds to the directory you launch ayaview from. You
can change this to an absolute path so logs are always written to the same file (append mode)









